package tn.esprit.nexaback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexabackApplicationTests {

	@Test
	void contextLoads() {
	}

}
