import {
  Dialog,
  DialogClasses,
  DialogModule,
  DialogStyle
} from "./chunk-76RNIDTA.js";
import "./chunk-BAG2UI53.js";
import "./chunk-Z5CC7JRX.js";
import "./chunk-NTNLRCQC.js";
import "./chunk-DI2AMJ7U.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-KOUSQTSF.js";
import "./chunk-7LIJGF2P.js";
import "./chunk-K7DQEIH6.js";
import "./chunk-4I733ZM4.js";
import "./chunk-RGJSUHV6.js";
import "./chunk-M656VMEZ.js";
import "./chunk-ITKLJM62.js";
import "./chunk-2FRJC6JJ.js";
import "./chunk-GFVF2TMO.js";
import "./chunk-AWYL7S6O.js";
import "./chunk-4QKMOSD7.js";
import "./chunk-4THGAS2G.js";
import "./chunk-FCPBNRVL.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-3OV72XIM.js";
export {
  Dialog,
  DialogClasses,
  DialogModule,
  DialogStyle
};
//# sourceMappingURL=primeng_dialog.js.map
